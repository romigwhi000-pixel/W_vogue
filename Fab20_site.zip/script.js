
// Fab20 interactions
document.addEventListener('DOMContentLoaded', () => {
  const emailForm = document.querySelector('#newsletter-form');
  const emailInput = document.querySelector('#email');
  const toast = (msg) => {
    const t = document.createElement('div');
    t.textContent = msg;
    t.style.position = 'fixed';
    t.style.left = '50%';
    t.style.top = '24px';
    t.style.transform = 'translateX(-50%)';
    t.style.background = 'linear-gradient(135deg,#ff7ab6,#a37bff)';
    t.style.color = '#0b0b10';
    t.style.padding = '12px 16px';
    t.style.borderRadius = '12px';
    t.style.fontWeight = '700';
    t.style.boxShadow = '0 8px 30px rgba(0,0,0,.35)';
    document.body.appendChild(t);
    setTimeout(()=>t.remove(), 2600);
  };
  if (emailForm){
    emailForm.addEventListener('submit', (e)=>{
      e.preventDefault();
      const v = emailInput.value.trim();
      if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)){
        toast('Enter a valid email ✨');
        emailInput.focus();
        return;
      }
      toast('You’re in! Welcome to Fab20 💖');
      emailInput.value='';
    });
  }
});
